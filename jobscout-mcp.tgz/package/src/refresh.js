#!/usr/bin/env node
/**
 * refresh.js — populate cache/bounties.json with REAL, verified bounty issues.
 * Sources: GitHub issue search (bounty labels). Classifies and drops scam/hw/points.
 * Run: node src/refresh.js   (writes ./cache/bounties.json)
 * Honest by design: if GitHub is rate-limited, it keeps the previous cache.
 */
import { execFileSync } from 'node:child_process';
import { writeFileSync, readFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const CACHE = join(root, 'cache', 'bounties.json');

const SCAM = ['bounty-plaza','bounty-bot','oss-verification-sandbox','agent-bounties','misakanet','sn-monetization-runtime','relayhop','frantic-board'];
const HW = ['wormhole','blackhole','tt-metal','tenstorrent','n150','p100a','cuda','npu'];
const PTS = ['reputation points','not money','hanzo rewards'];

const gh = a => execFileSync('gh', a, {encoding:'utf8', maxBuffer:1<<26});

function classify(b){
  const full=((b.title||'')+' '+(b.repo||b.url||'')).toLowerCase();
  const f=[];
  if (SCAM.some(s=>full.includes(s))) f.push('scam-ring');
  if (HW.some(s=>full.includes(s))) f.push('hardware-gated');
  if (PTS.some(s=>full.includes(s))) f.push('points-not-money');
  return f;
}

function search(q){
  const raw = gh(['api','-X','GET','search/issues','-f',`q=${q}`,'-f','sort=created','-f','order=desc','-f','per_page=50']);
  return JSON.parse(raw).items||[];
}

function run(){
  let prev = [];
  try { prev = JSON.parse(readFileSync(CACHE,'utf8')).bounties||[]; } catch {}
  const queries = [
    'is:issue is:open label:bounty created:>2026-07-01',
    'is:issue is:open label:bounty USDC created:>2026-07-01',
    'is:issue is:open label:bounty in:title fix created:>2026-07-01',
  ];
  const seen=new Set(); const out=[];
  for (const q of queries){
    let items=[]; try { items=search(q); } catch(e){ continue; }
    for (const it of items){
      if (seen.has(it.html_url)) continue; seen.add(it.html_url);
      const repo = it.repository_url.replace('https://api.github.com/repos/','');
      const m = (it.title+' '+(it.body||'')).match(/\$\s?([0-9][0-9,]{1,6})|([0-9][0-9,]{1,6})\s?(usdc|usdt|dai)/i);
      const b = { id:'gh:'+it.id, source:'github', repo, number:it.number, title:it.title,
        url:it.html_url, reward_amount: m?Number((m[1]||m[2]).replace(/,/g,'')):null,
        reward_currency: m?'USD/USDC':null, assigned:(it.assignees||[]).length>0,
        posted_at:it.created_at, status:'open' };
      b.flags = classify(b);
      if (b.flags.length) continue;            // drop flagged from served cache
      out.push(b);
    }
  }
  if (!out.length){
    console.error(`refresh: no clean results (rate-limit or no data); keeping ${prev.length} cached.`);
    process.exit(prev.length?0:2);
  }
  out.sort((a,b)=>(b.reward_amount||0)-(a.reward_amount||0));
  mkdirSync(join(root,'cache'),{recursive:true});
  writeFileSync(CACHE, JSON.stringify({ generated:new Date().toISOString(), count:out.length, bounties:out }, null, 2));
  console.log(`refresh: wrote ${out.length} clean bounties -> cache/bounties.json`);
}
run();
