#!/usr/bin/env node
/**
 * jobscout-mcp — MCP server (stdio, JSON-RPC 2.0, newline-delimited).
 * Exposes verified crypto-paying bounty feeds to AI agents.
 * Tools:
 *   list_bounties  - filtered, spam-classified bounty list (free)
 *   get_bounty     - details for one bounty by url/id (free)
 *   explain_trust  - why a listing was kept or flagged (free)
 * Data source: the public Bounty Scout API. Falls back to a cached snapshot.
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FEED_URL = process.env.JOBSCOUT_FEED || 'https://dinerbone3912.github.io/verified-bounties/bounties.json';
const CACHE = join(__dirname, '..', 'cache', 'bounties.json');

const SCAM = ['bounty-plaza','bounty-bot','oss-verification-sandbox','agent-bounties','misakanet','sn-monetization-runtime','relayhop','frantic-board'];
const HW = ['wormhole','blackhole','tt-metal','tenstorrent','n150','p100a','cuda','npu'];
const PTS = ['reputation points','not money','hanzo rewards'];

function classify(b){
  const full = ((b.title||'')+' '+(b.repo||b.url||'')).toLowerCase();
  const flags=[];
  if (SCAM.some(s=>full.includes(s))) flags.push('scam-ring');
  if (HW.some(s=>full.includes(s))) flags.push('hardware-gated');
  if (PTS.some(s=>full.includes(s))) flags.push('points-not-money');
  if (b.assigned) flags.push('assigned');
  return flags;
}

let cache = null;
async function loadFeed(){
  if (cache) return cache;
  try {
    const r = await fetch(FEED_URL, { signal: AbortSignal.timeout(15000) });
    if (r.ok) { cache = await r.json(); return cache; }
  } catch {}
  try { cache = JSON.parse(readFileSync(CACHE,'utf8')); } catch {}
  cache = cache || { bounties: [] };
  return cache;
}

function items(feed){ return Array.isArray(feed)?feed:(feed.bounties||feed.items||[]); }

async function toolListBounties(args){
  const feed = await loadFeed();
  let list = items(feed).map(b=>({ ...b, flags: classify(b) }));
  list = list.filter(b=>b.flags.length===0);          // clean by default
  if (args.min_reward!=null) list = list.filter(b=>(b.reward_amount||b.reward||0)>=Number(args.min_reward));
  if (args.q) { const q=String(args.q).toLowerCase(); list=list.filter(b=>((b.title||'')+' '+(b.tags||[]).join(' ')).toLowerCase().includes(q)); }
  if (args.include_flagged) list = items(feed).map(b=>({ ...b, flags: classify(b) }));
  list.sort((a,b)=>(b.reward_amount||b.reward||0)-(a.reward_amount||a.reward||0));
  const limit = Math.min(Number(args.limit)||20, 100);
  return { count: list.length, returned: Math.min(limit,list.length), bounties: list.slice(0,limit) };
}

async function toolGetBounty(args){
  const feed = await loadFeed();
  const key = String(args.id||args.url||'').toLowerCase();
  const hit = items(feed).find(b=>(b.url||'').toLowerCase().includes(key) || String(b.id||'')===String(args.id));
  if (!hit) return { found:false, id:args.id };
  return { found:true, bounty:{ ...hit, flags: classify(hit) } };
}

async function toolExplainTrust(args){
  const feed = await loadFeed();
  const key = String(args.id||args.url||'').toLowerCase();
  const hit = items(feed).find(b=>(b.url||'').toLowerCase().includes(key) || String(b.id||'')===String(args.id));
  if (!hit) return { found:false };
  const flags = classify(hit);
  return { found:true, kept: flags.length===0, flags,
    reason: flags.length? 'flagged: '+flags.join(', ') : 'live issue URL, no scam-ring/hardware/points markers' };
}

const TOOLS = [
  { name:'list_bounties', description:'List verified, spam-filtered crypto-paying software bounties (USDC/USDT/Dai). Returns clean items only unless include_flagged=true.',
    inputSchema:{ type:'object', properties:{ min_reward:{type:'number'}, q:{type:'string'}, limit:{type:'number'}, include_flagged:{type:'boolean'} } } },
  { name:'get_bounty', description:'Get full details for one bounty by url or id.', inputSchema:{ type:'object', properties:{ id:{type:'string'}, url:{type:'string'} } } },
  { name:'explain_trust', description:'Explain why a b bounty listing was kept or flagged.', inputSchema:{ type:'object', properties:{ id:{type:'string'}, url:{type:'string'} } } },
];

const HANDLERS = { list_bounties:toolListBounties, get_bounty:toolGetBounty, explain_trust:toolExplainTrust };

function send(obj){ process.stdout.write(JSON.stringify(obj)+'\n'); }
function result(id,res){ send({ jsonrpc:'2.0', id, result:res }); }
function error(id,code,msg){ send({ jsonrpc:'2.0', id, error:{ code, message:msg } }); }

async function handle(req){
  const { id, method, params } = req;
  if (method==='initialize') return result(id,{ protocolVersion:'2024-11-05', capabilities:{ tools:{} },
    serverInfo:{ name:'jobscout-mcp', version:'1.0.0' } });
  if (method==='notifications/initialized' || method==='initialized') return;
  if (method==='tools/list') return result(id,{ tools:TOOLS });
  if (method==='tools/call'){
    const name = params?.name; const args = params?.arguments||{};
    const fn = HANDLERS[name];
    if (!fn) return error(id,-32601,'unknown tool: '+name);
    try {
      const out = await fn(args);
      return result(id,{ content:[{ type:'text', text:JSON.stringify(out,null,2) }], isError:false });
    } catch(e){ return error(id,-32603, e.message); }
  }
  return error(id,-32601,'method not found: '+method);
}

let buf='';
process.stdin.setEncoding('utf8');
process.stdin.on('data',d=>{
  buf+=d; let i;
  while((i=buf.indexOf('\n'))>=0){
    const line=buf.slice(0,i).trim(); buf=buf.slice(i+1);
    if(!line) continue;
    try{ const req=JSON.parse(line); if(req.id!==undefined||req.method) handle(req); }
    catch(e){ send({jsonrpc:'2.0',id:null,error:{code:-32700,message:'parse error'}}); }
  }
});
process.stderr.write('jobscout-mcp ready (stdio)\n');
